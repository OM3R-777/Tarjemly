package com.omar.tarjemly

import android.app.*
import android.app.Activity
import android.content.pm.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.view.WindowManager.LayoutParams
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

class CaptureOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var busy = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "capture")
            .setContentTitle("ترجملي شغال").setContentText("اضغط الفقاعة لالتقاط القطعة الظاهرة").setSmallIcon(android.R.drawable.ic_menu_search).build()
        else Notification.Builder(this).setContentTitle("ترجملي شغال").setSmallIcon(android.R.drawable.ic_menu_search).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(9, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(9, notification)
        try {
            val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("captureData", Intent::class.java) else intent?.getParcelableExtra("captureData")
            if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            if (Build.VERSION.SDK_INT >= 34) projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, android.os.Handler(mainLooper))
            setupCapture()
            showBubble()
        } catch (e: Exception) { showToast("حصلت مشكلة في تشغيل التقاط الشاشة") ; stopSelf() }
        return START_NOT_STICKY
    }

    private fun setupCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay("TarjemlyScreen", metrics.widthPixels, metrics.heightPixels, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
    }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "ت"; textSize = 23f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(23, 107, 87)); elevation = 12f
            setOnClickListener { captureAndTranslate() }
        }
        val p = LayoutParams(58, 58, if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL; x = 18; y = 0 }
        wm.addView(b, p); bubble = b
    }

    private fun captureAndTranslate() {
        if (busy) return
        busy = true
        showPanel("ثواني.. بقرأ القطعة")
        reader?.setOnImageAvailableListener({ source ->
            var image = source.acquireLatestImage()
            if (image == null) { busy = false; return@setOnImageAvailableListener }
            try {
                val input = InputImage.fromMediaImage(image, 0)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(input)
                    .addOnSuccessListener { result ->
                        image.close(); image = null
                        val english = result.text.lines().filter { line -> line.any { it.isLetter() } }.joinToString("\n")
                        if (english.isBlank()) { showPanel("مش لاقي قطعة واضحة. خلّي النص ظاهر وكبّر حجمه وجرب تاني."); busy = false }
                        else translate(english)
                    }
                    .addOnFailureListener { image?.close(); showPanel("معرفتش أقرأ النص. جرّب تاني."); busy = false }
            } catch (e: Exception) { image?.close(); showPanel("حصل خطأ أثناء قراءة الشاشة."); busy = false }
        }, null)
        bubble?.postDelayed({
            if (busy) {
                // A capture callback should arrive shortly; if it doesn't, reset the reader listener for next tap.
                bubble?.postDelayed({ if (busy) { busy = false; showPanel("مش قادر ألتقط الشاشة دلوقتي. جرّب تاني.") } }, 3500)
            }
        }, 1800)
    }

    private fun translate(english: String) {
        val options = TranslatorOptions.Builder().setSourceLanguage("en").setTargetLanguage("ar").build()
        val translator = Translation.getClient(options)
        translator.downloadModelIfNeeded().addOnSuccessListener {
            translator.translate(english).addOnSuccessListener { arabic ->
                val phonetic = roughArabicPronunciation(english)
                showPanel("النطق بالعربي\n$phonetic\n\nالترجمة بالمصري\n${makeEgyptian(arabic)}")
                busy = false
            }.addOnFailureListener { showPanel("فشلت الترجمة. اتأكد من الإنترنت وجرب تاني."); busy = false; translator.close() }
        }.addOnFailureListener { showPanel("محتاج إنترنت لتنزيل نموذج الترجمة أول مرة."); busy = false; translator.close() }
    }

    // MVP phonetic rendering: makes English text easier to sound out; it is an approximation, not a dictionary-grade phonetic engine.
    private fun roughArabicPronunciation(text: String): String {
        val words = text.lowercase(Locale.US).replace(Regex("[^a-z0-9'\\s.,!?-]"), " ").split(Regex("\\s+")).filter { it.isNotBlank() }
        return words.joinToString(" ") { w ->
            if (w.all { it.isDigit() || it in ".,!?' -" }) w else {
                var s = w.replace("tion", "شن").replace("ture", "تشر").replace("th", "ث").replace("sh", "ش").replace("ch", "تش").replace("ph", "ف").replace("ee", "ي").replace("oo", "و").replace("ai", "اي").replace("ay", "اي").replace("ou", "او").replace("ow", "او").replace("a", "ا").replace("b", "ب").replace("c", "ك").replace("d", "د").replace("e", "ي").replace("f", "ف").replace("g", "ج").replace("h", "ه").replace("i", "ي").replace("j", "ج").replace("k", "ك").replace("l", "ل").replace("m", "م").replace("n", "ن").replace("o", "و").replace("p", "ب").replace("q", "ك").replace("r", "ر").replace("s", "س").replace("t", "ت").replace("u", "ا").replace("v", "ف").replace("w", "و").replace("x", "كس").replace("y", "ي").replace("z", "ز")
                s
            }
        }
    }

    // Keep the Arabic translation conversational and readable; avoid formal openers where simple alternatives are common.
    private fun makeEgyptian(arabic: String): String = arabic
        .replace("أنا اسمي ", "أنا ").replace("اسمي ", "أنا ")
        .replace("عمري عشرون عامًا", "عندي عشرين سنة").replace("عمري عشرون عاما", "عندي عشرين سنة")
        .replace("يرجى", "من فضلك").replace("لا أستطيع", "مش قادر").replace("أريد", "عايز")
        .replace("كيف حالك؟", "عامل إيه؟").replace("ماذا", "إيه").replace("لذلك", "عشان كده")

    private fun showPanel(message: String) {
        runOnUiThread {
            try {
                panel?.let { wm.removeView(it) }
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 18); setBackgroundColor(Color.WHITE); elevation = 18f }
                val close = Button(this).apply { text = "إغلاق"; setOnClickListener { panel?.let { wm.removeView(it) }; panel = null } }
                val content = TextView(this).apply { text = message; textSize = 18f; setTextColor(Color.rgb(31, 41, 37)); setPadding(0, 4, 0, 10); textDirection = TextView.TEXT_DIRECTION_RTL }
                val scroll = ScrollView(this); scroll.addView(content)
                box.addView(close); box.addView(scroll)
                val params = LayoutParams((resources.displayMetrics.widthPixels * .86).toInt(), LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") LayoutParams.TYPE_PHONE,
                    LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
                wm.addView(box, params); panel = box
            } catch (_: Exception) { }
        }
    }

    private fun showToast(s: String) { android.os.Handler(mainLooper).post { android.widget.Toast.makeText(this, s, android.widget.Toast.LENGTH_LONG).show() } }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) { val channel = NotificationChannel("capture", "ترجملي", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(channel) }
    }
    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release(); reader?.close(); projection?.stop(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
