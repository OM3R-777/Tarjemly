package com.omar.tarjemly

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val captureRequest = 741
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFFF7F8F6.toInt())
        }
        val title = TextView(this).apply { text = "ترجملي"; textSize = 30f; setTextColor(0xFF176B57.toInt()); gravity = Gravity.CENTER }
        val desc = TextView(this).apply {
            text = "ترجمة القطع الإنجليزية\nالنطق بحروف عربية + ترجمة بالمصري\n\nافتح الفقاعة فوق Teams واضغط عليها لقراءة النص الظاهر على الشاشة."
            textSize = 17f; gravity = Gravity.CENTER; setTextColor(0xFF26332F.toInt()); setPadding(0, 24, 0, 24)
        }
        val start = Button(this).apply { text = "تشغيل الفقاعة العائمة"; setOnClickListener { startOverlay() } }
        val note = TextView(this).apply {
            text = "ملاحظة: أول مرة قد يحتاج تنزيل نموذج الترجمة. لازم تسمح بتسجيل الشاشة وظهور التطبيق فوق التطبيقات الأخرى."
            textSize = 13f; gravity = Gravity.CENTER; setPadding(0, 18, 0, 0); setTextColor(0xFF59645F.toInt())
        }
        root.addView(title); root.addView(desc); root.addView(start); root.addView(note)
        setContentView(root)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل السماح بالظهور فوق التطبيقات، وبعدها افتح ترجملي واضغط تشغيل", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated in Android API but supported for this MVP")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, CaptureOverlayService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("captureData", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
            moveTaskToBack(true)
        }
    }
}
